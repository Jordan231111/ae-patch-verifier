"""Download APKs from the Google Play Store."""

__version__ = "4.2.1"
